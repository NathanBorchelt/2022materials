//Nathan Borchelt
//Assignment 10
public interface Reverse {
    public int[] reverse(int[] list);
}
