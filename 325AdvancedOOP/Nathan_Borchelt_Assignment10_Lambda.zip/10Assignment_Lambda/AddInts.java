//Nathan Borchelt
//Assignment 10
public interface AddInts {
    public int addInts(int a, int b);
}
