//Nathan Borchelt
//Assignment 10
public interface MinFunction {
    public int minFunction(int n1, int n2);
}
