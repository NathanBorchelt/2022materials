//Nathan Borchelt
//Assignment 10
public interface CountVowels {
    public int countVowels(String str);
}
