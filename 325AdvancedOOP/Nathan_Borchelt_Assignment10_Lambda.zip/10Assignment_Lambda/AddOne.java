//Nathan Borchelt
//Assignment 10
public interface AddOne {
    public int addOne(int n);
}
